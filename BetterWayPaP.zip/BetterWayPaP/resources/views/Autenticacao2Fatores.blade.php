<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Autenticacao 2 Fatores</title>
    <link rel="stylesheet" href="../resources/css/register-style.css">
</head>

<link rel="icon" type="image/png" sizes="50x50" href="resources/images/icon_logo-removebg-preview.png">

<body>

<div class="wrapper">
    <div class="title-text">
      <div class="title login">Autenticacao 2 Fatores</div>
      <div class="title signup">Registar</div>
    </div>
    <div class="form-container">
    
      <div class="form-inner">
        <form method="POST" action="user/two-factor-authentication">
          @csrf

          @if (auth()->user()->two_factor_secret)
          <div class="field btn">
            <div class="btn-layer"></div>
            @method('DELETE')
            <input type="submit" value="Retirar a autenticacao">
          </div>
          @else
          <div class="field btn">
            <div class="btn-layer"></div>
            <input type="submit" value="Permitir">
          </div>
          @endif
          
      </form>
      </div>
    </div>
  </div>

  <script src="../resources/js/registar.js"></script>

</body>
  

</html>