<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Coneccao com a base de dados</title>
</head>
<body>
    <div>
        <?php
            if (DB::connection()->getPdo()) {
                echo ("Sucedido". DB::connection()->getDatabase);
            }
        ?>
    </div>
</body>
</html><?php /**PATH C:\xampp\PaP\BetterWay\BetterWayPaP\resources\views/dbconn.blade.php ENDPATH**/ ?>