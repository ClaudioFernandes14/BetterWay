<?php echo e($slot); ?>

<?php /**PATH C:\xampp\PaP\BetterWay\BetterWayPaP\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>