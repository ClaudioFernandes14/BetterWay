<tr>
<td class="header">
<?php if(trim($slot) === 'Laravel'): ?>
<img  src="<?php echo e(asset('/resources/images/logo.png')); ?>" class='logo'>
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH C:\xampp\PaP\BetterWay\BetterWayPaP\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>