<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pagina nao Encontrada</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
    <section style="padding-top:100px;">
        <div class="container">
            <div class="row">
                <div class="cold-md-8 offset-md-2 text-center">
                    <h1 style="font-size: 162px">404</h1>
                    <h2>Pagina nao encontrada</h2>
                    <p>Porfavor volte para a pagina principal</p>
                    <a href="/" class="btn btn-primary">Clique aqui!</a>
                </div>
            </div>
        </div>
    </section>
</body>

<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" 
crossorigin="anonymous"></script>


</html>

<?php /**PATH C:\xampp\PaP\BetterWay\BetterWayPaP\resources\views/404.blade.php ENDPATH**/ ?>