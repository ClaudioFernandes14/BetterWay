<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Confirmacao</title>
    <link rel="stylesheet" href="../resources/css/register-style.css">
</head>
<body>
    <div class="wrapper">
        <div class="title-text">
            <div class="title login">Confirmar Conta</div>
        </div>
    </div>
    <div class="form-inner"> 
        <form class="login">
            <div class="field">
                <h1>hola</h1>
            </div>
            <div class="field">
            </div>
            <div class="field btn">
              <div class="btn-layer"></div>
              <input type="submit" value="Login">
            </div>
            <div class="signup-link"> <h2>teste</h2><a href="">Regista-te agora!</a> </div>
          </form>
    </div>

</body>
</html><?php /**PATH C:\xampp\PaP\BetterWay\BetterWayPaP\resources\views/confirmarConta.blade.php ENDPATH**/ ?>